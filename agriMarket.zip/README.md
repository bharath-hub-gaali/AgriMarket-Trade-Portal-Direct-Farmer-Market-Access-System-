# 🌾 AgriPredict India

AI-Powered Agriculture Crop Production Prediction System built using Streamlit and Scikit-Learn.

## 📁 Project Structure