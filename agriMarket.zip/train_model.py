import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# 1. Load Dataset
df = pd.read_csv("dataset.csv")

# 2. Features and Target separation
X = df.drop(columns=["Production"])
y = df["Production"]

# 3. Categorical and Numerical Columns
categorical_cols = ["Crop", "Variety", "State", "Export_State", "Season", "Unit", "Recommended Zone", "Trade_Type"]
numerical_cols = ["Quantity", "Cost"]

# 4. Pipeline with OneHotEncoder & RandomForest
preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_cols),
        ("num", "passthrough", numerical_cols)
    ]
)

pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("model", RandomForestRegressor(n_estimators=100, random_state=42))
])

# 5. Model Training
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
pipeline.fit(X_train, y_train)

# 6. Save Trained Model Pipeline
joblib.dump(pipeline, "model.pkl")
print("✅ Updated model.pkl with Export/Import support saved successfully!")